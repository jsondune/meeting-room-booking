# Notification & User Dropdown Fix

## ความสามารถที่เพิ่มมา

### 1. ระบบ Notification
- ✅ แสดงรายการแจ้งเตือนใน Dropdown
- ✅ โหลด Notification ผ่าน AJAX
- ✅ กดอ่านทีละรายการ
- ✅ กดอ่านทั้งหมด
- ✅ แสดง Badge จำนวนที่ยังไม่อ่าน
- ✅ หน้ารายการ Notification ทั้งหมด

### 2. User Dropdown
- ✅ แสดงชื่อและ Email
- ✅ เมนูโปรไฟล์
- ✅ เมนูเปลี่ยนรหัสผ่าน
- ✅ เมนูตั้งค่า
- ✅ ออกจากระบบ

## ไฟล์ที่ต้อง Copy

| ไฟล์ | วางที่ |
|------|--------|
| `NotificationController.php` | `backend/controllers/NotificationController.php` |
| `notification_index.php` | `backend/views/notification/index.php` |
| `main.php` | `backend/views/layouts/main.php` |

## สร้าง Folder

```
backend/views/notification/
```

## Database Table

ถ้ายังไม่มี table `notification` ให้รัน SQL:

```sql
CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `data` text,
  `link` varchar(500) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `sent_email` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notification_user` (`user_id`),
  KEY `idx_notification_is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## UI Preview

### Notification Dropdown
```
┌──────────────────────────────────┐
│ 🔔 การแจ้งเตือน     [✓] ดูทั้งหมด │
├──────────────────────────────────┤
│ 📅 การจองได้รับการอนุมัติ    ใหม่ │
│    ห้องประชุม A ได้รับการอนุมัติ  │
│    2 นาทีที่แล้ว                  │
├──────────────────────────────────┤
│ ⚠️ แจ้งเตือนการประชุม           │
│    การประชุมจะเริ่มใน 15 นาที    │
│    30 นาทีที่แล้ว                │
└──────────────────────────────────┘
```

### User Dropdown
```
┌──────────────────────────────────┐
│  [A] System Administrator        │
│      admin@example.com           │
├──────────────────────────────────┤
│  👤 โปรไฟล์                      │
│  🔑 เปลี่ยนรหัสผ่าน               │
├──────────────────────────────────┤
│  🚪 ออกจากระบบ                   │
└──────────────────────────────────┘
```

## API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| GET | `/notification/index` | หน้ารายการ notification |
| GET | `/notification/recent` | AJAX: ดึง notification ล่าสุด |
| POST | `/notification/mark-read?id=X` | AJAX: อ่าน notification |
| POST | `/notification/mark-all-read` | AJAX: อ่านทั้งหมด |
| GET | `/notification/unread-count` | AJAX: จำนวนที่ยังไม่อ่าน |
| POST | `/notification/delete?id=X` | AJAX: ลบ notification |

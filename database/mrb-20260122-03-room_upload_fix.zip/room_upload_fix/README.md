# Room Image Upload Fix (with Debug)

## ปัญหาที่พบ
- ไม่ทราบว่า upload ทำงานถึงขั้นตอนไหน
- เพิ่ม debug message เพื่อตรวจสอบ

## ไฟล์ที่ต้อง Copy

| ไฟล์ | วางที่ |
|------|--------|
| `MeetingRoom.php` | `common/models/MeetingRoom.php` |
| `RoomImage.php` | `common/models/RoomImage.php` |
| `RoomController.php` | `backend/controllers/RoomController.php` |
| `_form.php` | `backend/views/room/_form.php` |

## ทดสอบ

1. ไปที่ `http://backend.mrb.test/room/5/update`
2. เลือกรูปภาพ 1 ไฟล์
3. กด **บันทึก**
4. ดู Flash Message ที่แสดง จะมี **[DEBUG: ...]** บอกว่า:
   - `Files received: X` = จำนวนไฟล์ที่ได้รับ
   - `Existing: X` = จำนวนรูปที่มีอยู่แล้ว
   - `Max: X` = จำนวนที่อัปโหลดได้อีก
   - `Uploaded: X` = จำนวนที่อัปโหลดสำเร็จ

## ผลลัพธ์ที่เป็นไปได้

### ถ้า `Files received: 0`
- Form ไม่ส่งไฟล์มา
- ตรวจสอบ enctype ของ form

### ถ้า `Files received: 1` แต่ `Uploaded: 0`
- ไฟล์ได้รับแต่ save ไม่ได้
- ปัญหา folder permission หรือ path

### ถ้า `Uploaded: 1` แต่ไม่มีไฟล์ใน folder
- ไฟล์ save ไปผิด folder

---

**บอกผลลัพธ์ที่เห็นในหน้าเว็บมาด้วยนะครับ**

## สร้าง Folder

**สำคัญมาก!** ต้องสร้าง folder นี้ก่อน:

```
backend/web/uploads/rooms/
```

### วิธีสร้าง (Windows Command Prompt):
```cmd
cd C:\xampp\htdocs\mrbapp
mkdir backend\web\uploads\rooms
```

### หรือสร้างด้วย File Explorer:
1. ไปที่ `C:\xampp\htdocs\mrbapp\backend\web\`
2. สร้าง folder `uploads`
3. ภายใน uploads สร้าง folder `rooms`

## ตรวจสอบ Permission (Windows)
ปกติ Windows ไม่มีปัญหา permission แต่ถ้ายังไม่ได้:
- คลิกขวาที่ folder `uploads`
- Properties → Security
- ให้ IUSR และ IIS_IUSRS มีสิทธิ์ Write

## ทดสอบ
1. ไปที่ http://backend.mrb.test/room/5/update
2. เลือกรูปภาพ
3. กด Save
4. ตรวจสอบ:
   - folder `backend/web/uploads/rooms/5/` มีไฟล์รูปภาพ
   - table `room_image` มี record ใหม่

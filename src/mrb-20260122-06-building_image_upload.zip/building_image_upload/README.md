# Building Image Upload

## ✅ ความสามารถ

1. อัปโหลดรูปภาพได้สูงสุด **5 ไฟล์** ต่ออาคาร
2. รองรับ JPG, PNG, GIF, WEBP ขนาดไม่เกิน 2MB/รูป
3. แก้ไข/ลบรูปภาพที่มีอยู่ได้
4. ตั้งรูปหลัก (Primary) ใช้แสดงเป็น Thumbnail
5. Preview รูปก่อนอัปโหลด
6. ลบรูปหลักแล้วตั้งรูปแรกที่เหลือเป็นรูปหลักอัตโนมัติ
7. สร้าง Folder อัตโนมัติ
8. บันทึกลง Database
9. ลบ record จาก database เมื่อลบไฟล์จริง

## 📁 ไฟล์ที่ต้อง Copy

| ไฟล์ | วางที่ |
|------|--------|
| `Building.php` | `common/models/Building.php` |
| `BuildingImage.php` | `common/models/BuildingImage.php` |
| `BuildingController.php` | `backend/controllers/BuildingController.php` |
| `_form.php` | `backend/views/building/_form.php` |
| `view.php` | `backend/views/building/view.php` |

## 🗄️ Database

**รัน SQL ก่อน:**
```sql
-- ดูไฟล์ building_image.sql
```

## 📂 Folder Structure

```
backend/web/uploads/buildings/
├── 1/
│   ├── abc123.jpg
│   └── def456.png
├── 2/
│   └── ...
```

Folder จะถูกสร้างอัตโนมัติเมื่ออัปโหลด

## 🎨 UI Features

- แสดงจำนวนรูปที่มี/สูงสุด (เช่น 3/5 รูป)
- ปุ่มลบรูปภาพ
- Radio button เลือกรูปหลัก
- คลิกที่รูปเพื่อตั้งเป็นรูปหลัก
- Preview รูปใหม่ก่อนบันทึก
- แจ้งเตือนเมื่อครบ 5 รูป

## 🧪 ทดสอบ

1. รัน SQL สร้าง table `building_image`
2. Copy ไฟล์ทั้งหมด
3. ไปที่ `http://backend.mrb.test/building/1/update`
4. ทดสอบอัปโหลดรูป
5. ทดสอบลบรูป
6. ทดสอบตั้งรูปหลัก

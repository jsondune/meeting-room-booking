-- Notification Table (if not exists)
-- ตรวจสอบว่ามี table notification หรือยัง

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT 'info',
  `title` varchar(255) NOT NULL,
  `message` text,
  `link` varchar(500) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `data` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notification_user_id` (`user_id`),
  KEY `idx_notification_is_read` (`is_read`),
  KEY `idx_notification_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample notifications (optional)
-- INSERT INTO `notification` (`user_id`, `type`, `title`, `message`, `link`) VALUES
-- (1, 'booking', 'การจองใหม่', 'มีการจองห้องประชุมใหม่รอการอนุมัติ', '/booking/pending'),
-- (1, 'system', 'ยินดีต้อนรับ', 'ยินดีต้อนรับสู่ระบบจองห้องประชุม', NULL);

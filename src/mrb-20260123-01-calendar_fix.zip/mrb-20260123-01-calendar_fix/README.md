# Calendar Fix - ปฏิทินการจอง

## 🐛 ปัญหาที่พบ

1. **ปฏิทินไม่แสดงเป็นตาราง** - FullCalendar ไม่โหลด
2. **ไม่มีรายการจองแสดง** - extendedProps ไม่ครบ
3. **ข้อมูลใน Modal ไม่ถูกต้อง** - ขาด booking_code, time, viewUrl

## ✅ การแก้ไข

### BookingController.php
- เพิ่ม extendedProps ครบถ้วน: `booking_code`, `room_id`, `time`, `viewUrl`
- ขยายช่วงเวลาดึงข้อมูลเป็น 3 เดือน (เดือนก่อน, เดือนปัจจุบัน, เดือนหน้า)
- สีตามห้องประชุม (ไม่ใช่ตามสถานะ)
- เพิ่ม border color ตามสถานะ

### calendar.php
- โหลด FullCalendar v6 จาก CDN
- เพิ่ม error handling ถ้าโหลดไม่ได้
- แสดงวันที่แบบ พ.ศ.
- ปรับปรุง Modal แสดงรายละเอียด
- เพิ่ม Quick Create Modal
- Filter ตามห้องและสถานะ
- อัพเดทสถิติอัตโนมัติ

## 📁 ไฟล์ที่ต้อง Copy

| ไฟล์ | วางที่ |
|------|--------|
| `BookingController.php` | `backend/controllers/BookingController.php` |
| `calendar.php` | `backend/views/booking/calendar.php` |

## 🎨 Features

- ✅ ปฏิทินแสดงแบบ เดือน/สัปดาห์/รายการ
- ✅ สีตามห้องประชุม (แต่ละห้องมีสีต่างกัน)
- ✅ Border ตามสถานะ (เหลือง=รออนุมัติ, เขียว=อนุมัติ)
- ✅ คลิกวันที่เพื่อจองด่วน
- ✅ คลิกรายการเพื่อดูรายละเอียด
- ✅ Filter ตามห้อง/สถานะ
- ✅ สถิติจำนวนการจอง

## 🧪 ทดสอบ

1. ไปที่ `http://backend.mrb.test/booking/calendar`
2. ตรวจสอบว่าปฏิทินแสดงถูกต้อง
3. ลองคลิกที่รายการจอง
4. ลองใช้ Filter ห้อง/สถานะ
5. ลองคลิกที่วันที่ว่างเพื่อจองด่วน

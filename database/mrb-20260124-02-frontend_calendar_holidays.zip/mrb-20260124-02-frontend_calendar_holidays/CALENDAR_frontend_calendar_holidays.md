# Frontend Calendar Holidays V2 - แก้ไขวันหยุดไม่แสดง

## 🐛 ปัญหาเดิม
- ดึงวันหยุดเพียง 3 เดือน (เดือนก่อน, ปัจจุบัน, เดือนหน้า)
- วันหยุดที่อยู่เดือนอื่นๆ ไม่แสดง

## ✅ การแก้ไข
- เปลี่ยนให้ดึงวันหยุด **ทั้งปี** (1 ม.ค. - 31 ธ.ค.)

```php
// เดิม - ดึงเพียง 3 เดือน
$holidays = Holiday::find()
    ->where(['between', 'holiday_date', $startDate, $endDate])
    ...

// ใหม่ - ดึงทั้งปี
$currentYear = date('Y');
$holidayStartDate = $currentYear . '-01-01';
$holidayEndDate = $currentYear . '-12-31';

$holidays = Holiday::find()
    ->where(['between', 'holiday_date', $holidayStartDate, $holidayEndDate])
    ...
```

## 📁 ไฟล์ที่ต้อง Copy

| ไฟล์ | วางที่ |
|------|--------|
| `SiteController.php` | `frontend/controllers/SiteController.php` |
| `calendar.php` | `frontend/views/site/calendar.php` |

## 🧪 ทดสอบ

1. ไปที่ `http://frontend.mrb.test/site/calendar`
2. เลื่อนไปดูเดือน มีนาคม, เมษายน, พฤษภาคม
3. วันหยุดควรแสดง background สีแดงอ่อน

-- ตรวจสอบว่า table notification มีอยู่หรือไม่
-- ถ้าไม่มีให้รัน SQL นี้

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `data` text,
  `link` varchar(500) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `sent_email` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notification_user` (`user_id`),
  KEY `idx_notification_is_read` (`is_read`),
  KEY `idx_notification_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ตัวอย่าง notification สำหรับทดสอบ
INSERT INTO `notification` (`user_id`, `type`, `title`, `message`, `link`, `is_read`, `created_at`) VALUES
(1, 'booking_approved', 'การจองได้รับการอนุมัติ', 'การจองห้องประชุม A วันที่ 25 ม.ค. 2568 ได้รับการอนุมัติแล้ว', '/booking/view?id=1', 0, NOW()),
(1, 'booking_reminder', 'แจ้งเตือนการประชุม', 'การประชุมของคุณจะเริ่มใน 15 นาที', '/booking/view?id=2', 0, DATE_SUB(NOW(), INTERVAL 30 MINUTE)),
(1, 'system', 'ยินดีต้อนรับ', 'ยินดีต้อนรับสู่ระบบจองห้องประชุม', NULL, 1, DATE_SUB(NOW(), INTERVAL 1 DAY));

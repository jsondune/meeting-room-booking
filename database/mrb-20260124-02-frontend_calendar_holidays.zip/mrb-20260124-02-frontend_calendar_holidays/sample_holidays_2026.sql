-- ตัวอย่างข้อมูลวันหยุด พ.ศ. 2569 (ค.ศ. 2026)
-- รันถ้ายังไม่มีข้อมูลวันหยุด

INSERT INTO holiday (holiday_date, name_th, name_en, holiday_type, is_active, created_at) VALUES
('2026-01-01', 'วันขึ้นปีใหม่', 'New Year Day', 'national', 1, NOW()),
('2026-02-26', 'วันมาฆบูชา', 'Makha Bucha Day', 'national', 1, NOW()),
('2026-04-06', 'วันจักรี', 'Chakri Memorial Day', 'national', 1, NOW()),
('2026-04-13', 'วันสงกรานต์', 'Songkran Festival', 'national', 1, NOW()),
('2026-04-14', 'วันสงกรานต์', 'Songkran Festival', 'national', 1, NOW()),
('2026-04-15', 'วันสงกรานต์', 'Songkran Festival', 'national', 1, NOW()),
('2026-05-01', 'วันแรงงานแห่งชาติ', 'National Labour Day', 'national', 1, NOW()),
('2026-05-04', 'วันฉัตรมงคล', 'Coronation Day', 'national', 1, NOW()),
('2026-05-13', 'วันวิสาขบูชา', 'Visakha Bucha Day', 'national', 1, NOW()),
('2026-06-03', 'วันเฉลิมพระชนมพรรษา สมเด็จพระนางเจ้าฯ พระบรมราชินี', 'Queen Suthida Birthday', 'national', 1, NOW()),
('2026-07-10', 'วันอาสาฬหบูชา', 'Asanha Bucha Day', 'national', 1, NOW()),
('2026-07-11', 'วันเข้าพรรษา', 'Buddhist Lent Day', 'national', 1, NOW()),
('2026-07-28', 'วันเฉลิมพระชนมพรรษา พระบาทสมเด็จพระเจ้าอยู่หัว', 'King Birthday', 'national', 1, NOW()),
('2026-08-12', 'วันเฉลิมพระชนมพรรษา สมเด็จพระบรมราชชนนีพันปีหลวง (วันแม่แห่งชาติ)', 'Queen Mother Birthday / Mother Day', 'national', 1, NOW()),
('2026-10-13', 'วันคล้ายวันสวรรคต พระบาทสมเด็จพระบรมชนกาธิเบศร มหาภูมิพลอดุลยเดชมหาราช บรมนาถบพิตร', 'King Bhumibol Memorial Day', 'national', 1, NOW()),
('2026-10-23', 'วันปิยมหาราช', 'Chulalongkorn Day', 'national', 1, NOW()),
('2026-12-05', 'วันคล้ายวันพระบรมราชสมภพ พระบาทสมเด็จพระบรมชนกาธิเบศร (วันพ่อแห่งชาติ)', 'King Bhumibol Birthday / Father Day', 'national', 1, NOW()),
('2026-12-10', 'วันรัฐธรรมนูญ', 'Constitution Day', 'national', 1, NOW()),
('2026-12-31', 'วันสิ้นปี', 'New Year Eve', 'national', 1, NOW())
ON DUPLICATE KEY UPDATE name_th = VALUES(name_th), is_active = 1;

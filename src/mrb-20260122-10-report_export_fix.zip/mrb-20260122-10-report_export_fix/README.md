# Report Export Fix - PDF, Excel, Print

## ✅ Features ที่แก้ไข/เพิ่มเติม

### 1. ปุ่ม PDF
- คลิกแล้วจะ export เป็น HTML พร้อมปุ่ม Print
- ใช้งานได้โดย Print to PDF ใน browser (Ctrl+P แล้วเลือก Save as PDF)
- แสดงข้อมูลสรุปและรายละเอียดการจอง

### 2. ปุ่ม Excel
- Export เป็น CSV (รองรับ UTF-8 ภาษาไทย)
- เปิดได้ทั้ง Excel และ Google Sheets
- มีข้อมูลสรุปและรายละเอียด

### 3. ปุ่มพิมพ์
- ใช้ window.print() เปิดหน้าต่างพิมพ์
- รองรับ Print to PDF

### 4. Notification Bell 🔔
- แสดงจำนวน notification ที่ยังไม่ได้อ่าน
- คลิกเพื่อดู dropdown รายการ
- AJAX loading เมื่อเปิด dropdown

### 5. User Dropdown Menu
- แสดงชื่อผู้ใช้และ avatar
- เมนู: โปรไฟล์, เปลี่ยนรหัสผ่าน, ออกจากระบบ

## 📁 ไฟล์ที่ต้อง Copy

| ไฟล์ | วางที่ |
|------|--------|
| `ReportController.php` | `backend/controllers/ReportController.php` |
| `NotificationController.php` | `backend/controllers/NotificationController.php` |
| `Notification.php` | `common/models/Notification.php` |
| `main.php` | `backend/views/layouts/main.php` |
| `views_notification/index.php` | `backend/views/notification/index.php` |

## 🗄️ Database

**รัน SQL ก่อน (ถ้ายังไม่มี table notification):**

```sql
CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT 'info',
  `title` varchar(255) NOT NULL,
  `message` text,
  `link` varchar(500) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `data` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notification_user_id` (`user_id`),
  KEY `idx_notification_is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## 🎨 การใช้งาน Export

### PDF Export
1. คลิกปุ่ม **PDF**
2. จะเปิดหน้าใหม่แสดง report
3. คลิก **พิมพ์รายงาน / บันทึก PDF**
4. เลือก **Save as PDF** ใน print dialog

### Excel Export
1. คลิกปุ่ม **Excel**
2. ไฟล์ CSV จะถูก download
3. เปิดด้วย Excel หรือ Google Sheets

### Print
1. คลิกปุ่ม **พิมพ์**
2. จะเปิด print dialog
3. เลือก printer หรือ Save as PDF

## 📊 ข้อมูลใน Export

### สรุปภาพรวม
- จำนวนการจองทั้งหมด
- ชั่วโมงใช้งานรวม  
- ระยะเวลาเฉลี่ยต่อการจอง
- สถานะการจอง (pending, approved, etc.)

### รายละเอียด
- รหัสการจอง
- วันที่, เวลา
- ห้องประชุม
- ผู้จอง, หน่วยงาน
- หัวข้อ, สถานะ
